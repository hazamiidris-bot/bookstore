<?php
session_start();
include "../config/database.php";

$token = $_GET['token'] ?? '';
$error = "";
$success = "";

$q = $conn->prepare("SELECT * FROM password_requests WHERE token=?");
$q->execute([$token]);
$req = $q->fetch(PDO::FETCH_ASSOC);

if($req && $req['status'] == 'approved' && isset($_POST['save'])){

    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm']);

    if(strlen($password) < 6){

        $error = "Password minimal 6 karakter.";

    }elseif($password != $confirm){

        $error = "Konfirmasi password tidak sama.";

    }else{

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $upd = $conn->prepare("UPDATE users SET password=? WHERE id=?");
        $upd->execute([$hash, $req['user_id']]);

        $done = $conn->prepare("UPDATE password_requests SET status='used' WHERE id=?");
        $done->execute([$req['id']]);

        $req['status'] = 'used';
        $success = "Password berhasil diganti. Silakan login.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Password Baru - Zook BookStore</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>

<div class="container">

    <div class="left">
        <h1>Zook BookStore</h1>
        <p>
            Password baru hanya bisa dibuat setelah
            permintaanmu disetujui admin.
        </p>
    </div>

    <div class="right">

        <h2>Password Baru</h2>

        <?php if(!$req){ ?>

            <p class="subtitle">Permintaan tidak ditemukan.</p>
            <p class="login-text"><a href="request_password.php">Ajukan permintaan baru</a></p>

        <?php }elseif($success != ""){ ?>

            <p class="subtitle"><?= htmlspecialchars($success) ?></p>
            <p class="login-text"><a href="login.php">Login</a></p>

        <?php }elseif($req['status'] == 'pending'){ ?>

            <p class="subtitle">
                Permintaanmu sedang menunggu persetujuan admin.
                Simpan halaman ini (bookmark), lalu refresh nanti.
            </p>
            <p class="login-text"><a href="">Cek status lagi</a></p>

        <?php }elseif($req['status'] == 'rejected'){ ?>

            <p class="subtitle">Permintaan ditolak atau diganti dengan permintaan baru.</p>
            <p class="login-text"><a href="request_password.php">Ajukan permintaan baru</a></p>

        <?php }elseif($req['status'] == 'used'){ ?>

            <p class="subtitle">Permintaan ini sudah dipakai.</p>
            <p class="login-text"><a href="login.php">Login</a></p>

        <?php }else{ ?>

            <p class="subtitle">Disetujui admin. Silakan buat password baru.</p>

            <?php if($error != ""){ ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php } ?>

            <form method="POST">

                <div class="input-box">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" placeholder="Password Baru" required>
                </div>

                <div class="input-box">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="confirm" placeholder="Konfirmasi Password" required>
                </div>

                <button class="register-btn" name="save">Simpan Password</button>

            </form>

        <?php } ?>

    </div>

</div>

</body>
</html>