<?php
session_start();
include "../config/database.php";

$error = "";

if(isset($_POST['request'])){

    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);

    $cek = $conn->prepare("SELECT id FROM users WHERE username=? AND email=?");
    $cek->execute([$username, $email]);
    $user = $cek->fetch(PDO::FETCH_ASSOC);

    if(!$user){

        $error = "Username dan email tidak cocok.";

    }else{

        // batalkan permintaan lama yang masih aktif
        $old = $conn->prepare("UPDATE password_requests SET status='rejected'
                               WHERE user_id=? AND status IN ('pending','approved')");
        $old->execute([$user['id']]);

        $token = bin2hex(random_bytes(16));

        $ins = $conn->prepare("INSERT INTO password_requests(user_id, token) VALUES(?,?)");
        $ins->execute([$user['id'], $token]);

        header("Location: set_new_password.php?token=" . $token);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lupa Password - Zook BookStore</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body>

<div class="container">

    <div class="left">
        <h1>Zook BookStore</h1>
        <p>
            Lupa atau ingin mengganti password?
            Ajukan permintaan, lalu tunggu persetujuan admin.
        </p>
    </div>

    <div class="right">

        <h2>Ganti Password</h2>
        <p class="subtitle">Masukkan username dan email akunmu.</p>

        <?php if($error != ""){ ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php } ?>

        <form method="POST">

            <div class="input-box">
                <i class="fa-solid fa-user"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>

            <div class="input-box">
                <i class="fa-solid fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <button class="register-btn" name="request">Ajukan Permintaan</button>

        </form>

        <p class="login-text">
            <a href="login.php">Kembali ke Login</a>
        </p>

    </div>

</div>

</body>
</html>