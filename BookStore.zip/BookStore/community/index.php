<?php
session_start();
include "../config/database.php";

$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] == "admin";

// Buat post baru
if(isset($_POST['post'])){

    if(!isset($_SESSION['id'])){
        header("Location: ../User/login.php");
        exit;
    }

    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $type = ($_POST['type'] == 'kritik') ? 'kritik' : 'komentar';

    $sql = $conn->prepare("INSERT INTO community_posts (user_id, title, content, type, created_at) VALUES (?,?,?,?, NOW())");
    $sql->execute([$_SESSION['id'], $title, $content, $type]);

    header("Location: index.php");
    exit;
}

// Balas post
if(isset($_POST['reply'])){

    if(!isset($_SESSION['id'])){
        header("Location: ../User/login.php");
        exit;
    }

    $post_id = (int) $_POST['post_id'];
    $content = trim($_POST['reply_content']);

    // cek jenis post: kritik hanya boleh dibalas admin
    $cek = $conn->prepare("SELECT type FROM community_posts WHERE id=?");
    $cek->execute([$post_id]);
    $type = $cek->fetchColumn();

    $boleh = ($type == 'komentar') || $isAdmin;

    if($boleh && $content != ""){
        $sql = $conn->prepare("INSERT INTO community_replies (post_id, user_id, content, created_at) VALUES (?,?,?, NOW())");
        $sql->execute([$post_id, $_SESSION['id'], $content]);
    }

    header("Location: index.php#post-" . $post_id);
    exit;
}

$posts = $conn->query("
SELECT community_posts.*, users.fullname
FROM community_posts
LEFT JOIN users ON community_posts.user_id = users.id
ORDER BY community_posts.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$replyStmt = $conn->prepare("
SELECT community_replies.*, users.fullname, users.role
FROM community_replies
LEFT JOIN users ON community_replies.user_id = users.id
WHERE community_replies.post_id = ?
ORDER BY community_replies.id ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Community - Zook BookStore</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
.community-wrap{ max-width:700px; margin:40px auto; padding:0 20px; }
.post-form{ background:white; padding:20px; border-radius:15px; box-shadow:0 5px 15px rgba(0,0,0,.08); margin-bottom:30px; }
.post-form input[type=text], .post-form select{ width:100%; padding:12px; border:1px solid #ddd; border-radius:10px; font-family:inherit; margin-bottom:12px; background:white; }
.post-form textarea{ width:100%; padding:12px; border:1px solid #ddd; border-radius:10px; resize:vertical; min-height:80px; font-family:inherit; }
.post-form button{ margin-top:12px; padding:10px 20px; background:#2563EB; color:white; border:none; border-radius:8px; cursor:pointer; }
.post-card{ background:white; padding:20px; border-radius:15px; box-shadow:0 5px 15px rgba(0,0,0,.08); margin-bottom:20px; }
.post-card h3{ margin-bottom:8px; }
.post-card .author{ font-weight:600; margin-bottom:5px; color:#2563EB; }
.post-card .date{ font-size:12px; color:gray; margin-bottom:10px; }
.badge{ display:inline-block; font-size:11px; font-weight:600; padding:3px 10px; border-radius:20px; margin-bottom:8px; }
.badge.komentar{ background:#dbeafe; color:#1d4ed8; }
.badge.kritik{ background:#fee2e2; color:#dc2626; }
.badge.admin{ background:#2563EB; color:white; margin:0 0 0 6px; padding:2px 8px; }
.replies{ margin-top:15px; padding-top:12px; border-top:1px solid #eee; }
.reply{ background:#f5f7ff; padding:10px 14px; border-radius:10px; margin-bottom:10px; }
.reply.by-admin{ background:#eef2ff; border-left:4px solid #2563EB; }
.reply .author{ font-size:13px; font-weight:600; color:#2563EB; }
.reply .date{ font-size:11px; color:gray; margin-bottom:5px; }
.reply-form{ display:flex; gap:8px; margin-top:10px; }
.reply-form input[type=text]{ flex:1; padding:10px; border:1px solid #ddd; border-radius:10px; font-family:inherit; }
.reply-form button{ padding:10px 16px; background:#2563EB; color:white; border:none; border-radius:8px; cursor:pointer; }
.note{ font-size:12px; color:gray; margin-top:8px; }
</style>
</head>
<body>

<?php include "../includes/navbar.php"; ?>

<div class="community-wrap">

<h2>Community</h2>
<br>

<?php if(isset($_SESSION['id'])){ ?>

<div class="post-form">
<form method="POST">

<select name="type" required>
<option value="komentar">💬 Komentar (bisa dibalas semua user)</option>
<option value="kritik">📝 Kritik / Saran (dibalas oleh admin)</option>
</select>

<input type="text" name="title" placeholder="Judul postingan..." required>
<textarea name="content" placeholder="Bagikan pendapatmu tentang buku atau toko..." required></textarea>
<br>
<button type="submit" name="post">Posting</button>
</form>
</div>

<?php } else { ?>

<p><a href="../User/login.php">Login</a> untuk membuat post.</p>
<br>

<?php } ?>

<?php foreach($posts as $post){

    $isKritik = ($post['type'] ?? 'komentar') == 'kritik';
    $bisaBalas = isset($_SESSION['id']) && (!$isKritik || $isAdmin);
?>

<div class="post-card" id="post-<?= $post['id'] ?>">

<span class="badge <?= $isKritik ? 'kritik' : 'komentar' ?>">
<?= $isKritik ? '📝 Kritik / Saran' : '💬 Komentar' ?>
</span>

<h3><?= htmlspecialchars($post['title']) ?></h3>
<div class="author"><?= htmlspecialchars($post['fullname'] ?? 'Anonim') ?></div>
<div class="date"><?= date('d M Y, H:i', strtotime($post['created_at'])) ?></div>
<p><?= nl2br(htmlspecialchars($post['content'])) ?></p>

<div class="replies">

<?php
$replyStmt->execute([$post['id']]);
foreach($replyStmt->fetchAll(PDO::FETCH_ASSOC) as $r){
    $byAdmin = ($r['role'] ?? '') == 'admin';
?>
<div class="reply <?= $byAdmin ? 'by-admin' : '' ?>">
<div class="author">
<?= htmlspecialchars($r['fullname'] ?? 'Anonim') ?>
<?php if($byAdmin){ ?><span class="badge admin">Admin</span><?php } ?>
</div>
<div class="date"><?= date('d M Y, H:i', strtotime($r['created_at'])) ?></div>
<?= nl2br(htmlspecialchars($r['content'])) ?>
</div>
<?php } ?>

<?php if($bisaBalas){ ?>

<form method="POST" class="reply-form">
<input type="hidden" name="post_id" value="<?= $post['id'] ?>">
<input type="text" name="reply_content" placeholder="Tulis balasan..." required>
<button type="submit" name="reply">Balas</button>
</form>

<?php } elseif($isKritik){ ?>

<div class="note">Kritik / saran ini hanya bisa dibalas oleh admin.</div>

<?php } else { ?>

<small><a href="../User/login.php">Login</a> untuk membalas.</small>

<?php } ?>

</div>

</div>

<?php } ?>

</div>

<?php include "../includes/footer.php"; ?>

</body>
</html>