<?php
session_start();

$fotoFile = "";
$fotoAda  = false;

foreach(['jpg','jpeg','png','webp'] as $ext){
    if(file_exists(__DIR__ . "/../assets/img/admin." . $ext)){
        $fotoFile = "../assets/img/admin." . $ext;
        $fotoAda  = true;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>About Us - Zook BookStore</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
.about-wrap{ max-width:800px; margin:50px auto; padding:0 20px; }
.about-wrap h1{ font-size:36px; margin-bottom:10px; }
.about-wrap p{ line-height:1.8; color:#444; margin-bottom:20px; }
.about-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin-top:40px; }
.about-card{ background:white; padding:25px; border-radius:15px; box-shadow:0 5px 15px rgba(0,0,0,.08); text-align:center; }
.about-card i{ font-size:32px; color:#2563EB; margin-bottom:15px; }
.about-card h3{ margin-bottom:10px; }
.about-card p{ font-size:14px; color:#666; margin:0; }

/* Kontak Admin */
.contact-card{
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
    text-align:center;
    margin-top:50px;
    transition:.3s;
}
.contact-card:hover{
    transform:translateY(-5px);
}

/* Foto admin */
.admin-photo{
    width:130px;
    height:130px;
    border-radius:50%;
    object-fit:cover;
    object-position:center top;
    border:4px solid #2563EB;
    box-shadow:0 8px 20px rgba(37,99,235,.25);
    margin-bottom:15px;
}
.admin-photo-placeholder{
    width:130px;
    height:130px;
    border-radius:50%;
    background:#eef2ff;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    margin-bottom:15px;
}
.admin-photo-placeholder i{
    font-size:50px;
    color:#2563EB;
    margin:0;
    background:none;
    -webkit-text-fill-color:#2563EB;
}

.contact-card i.fa-instagram{
    display:block;
    font-size:38px;
    background:linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    margin-bottom:15px;
}
.contact-card h3{
    margin-bottom:8px;
    font-size:22px;
}
.contact-card p{
    color:#666;
    margin-bottom:5px;
}
.contact-card a{
    display:inline-block;
    margin-top:18px;
    background:#2563EB;
    color:white;
    padding:12px 26px;
    border-radius:10px;
    text-decoration:none;
    font-weight:500;
    transition:.3s;
}
.contact-card a:hover{
    background:#1d4ed8;
}
</style>
</head>
<body>

<?php include "../includes/navbar.php"; ?>

<div class="about-wrap">

<h1>Tentang Zook BookStore</h1>

<p>
Zook BookStore adalah toko buku online yang menghadirkan koleksi manga, novel,
dan buku-buku pilihan untuk para pecinta cerita. Kami percaya setiap buku
punya cerita yang layak dibaca dan dibagikan.
</p>

<p>
Selain berbelanja, Zook BookStore juga menjadi ruang bagi komunitas pembaca
untuk berdiskusi, berbagi rekomendasi, dan terhubung dengan sesama pecinta buku
lewat fitur Community kami.
</p>

<div class="about-grid">

<div class="about-card">
<i class="fa-solid fa-book"></i>
<h3>Koleksi Lengkap</h3>
<p>Ratusan judul buku dari berbagai genre dan penulis.</p>
</div>

<div class="about-card">
<i class="fa-solid fa-truck-fast"></i>
<h3>Pengiriman Cepat</h3>
<p>Pesanan diproses dan dikirim dengan cepat ke seluruh Indonesia.</p>
</div>

<div class="about-card">
<i class="fa-solid fa-users"></i>
<h3>Komunitas Aktif</h3>
<p>Bergabung dan diskusi dengan sesama pembaca lainnya.</p>
</div>

</div>

<!-- Kontak Admin -->
<div class="contact-card">

    <?php if($fotoAda){ ?>
        <img src="<?= $fotoFile ?>" alt="Foto Admin" class="admin-photo">
    <?php } else { ?>
        <div class="admin-photo-placeholder"><i class="fa-solid fa-user"></i></div>
    <?php } ?>

    <i class="fa-brands fa-instagram"></i>
    <h3>Kontak Admin</h3>
    <p>Butuh bantuan atau ingin bertanya?</p>
    <p><strong>@hazami_idris</strong></p>
    <a href="https://www.instagram.com/hazami_idris?cplk=MTg1aTZkMngzOGxtMg==" target="_blank">
        Hubungi via Instagram
    </a>
</div>

</div>

<?php include "../includes/footer.php"; ?>

</body>
</html>