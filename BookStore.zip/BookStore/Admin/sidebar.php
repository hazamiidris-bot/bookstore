<div class="sidebar">

<h2>Zook<br>BookStore</h2>

<ul>

<li><a href="dashboard.php">📊 Dashboard</a></li>

<li><a href="books.php">📚 Buku</a></li>

<li><a href="category.php">📁 Kategori</a></li>

<li><a href="banner.php">🖼️ Banner</a></li>

<li><a href="user.php">👤 User</a></li>

<li><a href="approve_password.php">🔑 Ganti Password</a></li>

<li><a href="pesanan.php">🛒 Pesanan</a></li>

<li><a href="../community/index.php">💬 Komunitas (Balas)</a></li>
 
<li><a href="../index.php" target="_blank">🌐 Lihat Website</a></li>

<li><a href="settings.php">⚙️ Pengaturan Pembayaran</a></li>

<li><a href="../User/logout.php">🚪 Logout</a></li>

</ul>

</div>