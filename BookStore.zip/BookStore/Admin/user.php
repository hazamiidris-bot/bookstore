<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit;
}

include "../config/database.php";

// Ambil semua user
$users = $conn->query("SELECT * FROM users ORDER BY id DESC");

// Ambil request password yang pending
$requests = $conn->query("
    SELECT pr.*, u.email 
    FROM password_requests pr 
    LEFT JOIN users u ON pr.user_id = u.id 
    WHERE pr.status = 'pending' 
    ORDER BY pr.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola User</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
<div class="wrapper">
    <?php include "sidebar.php"; ?>

    <div class="content">
        <h1>Kelola User</h1>
        <br>

        <!-- SECTION REQUEST GANTI PASSWORD -->
        <h2 style="margin-bottom:15px;">Permintaan Ganti Password</h2>

        <?php if ($requests->rowCount() == 0): ?>
            <p style="color:#666;margin-bottom:30px;">Tidak ada permintaan yang menunggu.</p>
        <?php else: ?>
            <table style="margin-bottom:40px;">
                <tr>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Alasan</th>
                    <th>Waktu</th>
                    <th>Aksi</th>
                </tr>
                <?php foreach ($requests as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['fullname']) ?></td>
                    <td><?= htmlspecialchars($r['username']) ?></td>
                    <td><?= htmlspecialchars($r['email'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($r['reason']) ?></td>
                    <td><?= date('d M Y H:i', strtotime($r['created_at'])) ?></td>
                    <td>
                        <a href="approve_password.php?id=<?= $r['id'] ?>&action=approve" 
                           style="color:green;margin-right:10px;"
                           onclick="return confirm('Approve permintaan ini?')">Approve</a>
                        <a href="approve_password.php?id=<?= $r['id'] ?>&action=reject" 
                           style="color:red;"
                           onclick="return confirm('Tolak permintaan ini?')">Reject</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <!-- SECTION DAFTAR USER -->
        <h2 style="margin-bottom:15px;">Daftar User</h2>
        <table>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= htmlspecialchars($u['fullname']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= htmlspecialchars($u['role']) ?></td>
                <td>
                    <?php if ($u['id'] != $_SESSION['id']): ?>
                        <a href="delete_user.php?id=<?= $u['id'] ?>" onclick="return confirm('Hapus user ini?')">Hapus</a>
                    <?php else: ?>
                        <span style="color:gray">(Kamu)</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
</body>
</html>