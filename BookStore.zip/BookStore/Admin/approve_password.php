<?php
session_start();

if(!isset($_SESSION['id']) || $_SESSION['role'] != "admin"){
    header("Location: ../User/login.php");
    exit;
}

include "../config/database.php";

if(isset($_POST['id']) && isset($_POST['action'])){

    $status = ($_POST['action'] == 'approve') ? 'approved' : 'rejected';

    $sql = $conn->prepare("UPDATE password_requests SET status=? WHERE id=? AND status='pending'");
    $sql->execute([$status, $_POST['id']]);

    header("Location: approve_password.php");
    exit;
}

$requests = $conn->query("
SELECT password_requests.*, users.fullname, users.username, users.email
FROM password_requests
JOIN users ON password_requests.user_id = users.id
ORDER BY (password_requests.status='pending') DESC, password_requests.id DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Permintaan Ganti Password</title>
<link rel="stylesheet" href="../assets/css/admin.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

<div class="wrapper">

<?php include "sidebar.php"; ?>

<div class="content">

<h1>Permintaan Ganti Password</h1>
<br>

<table>
<tr>
<th>Nama</th>
<th>Username</th>
<th>Email</th>
<th>Waktu</th>
<th>Status</th>
<th>Aksi</th>
</tr>

<?php foreach($requests as $r){ ?>
<tr>
<td><?= htmlspecialchars($r['fullname']) ?></td>
<td><?= htmlspecialchars($r['username']) ?></td>
<td><?= htmlspecialchars($r['email']) ?></td>
<td><?= date('d M Y, H:i', strtotime($r['created_at'])) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>
<td>
<?php if($r['status'] == 'pending'){ ?>
<form method="POST" style="display:inline">
<input type="hidden" name="id" value="<?= $r['id'] ?>">
<button name="action" value="approve" onclick="return confirm('Setujui permintaan ini?')">Setujui</button>
<button name="action" value="reject" onclick="return confirm('Tolak permintaan ini?')">Tolak</button>
</form>
<?php } else { ?>
-
<?php } ?>
</td>
</tr>
<?php } ?>

</table>

</div>
</div>

</body>
</html>